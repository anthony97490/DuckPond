package Duckoon;

public class Main {
	
	public static void main(String[] args) {
		
		MyFrame myFrame = new MyFrame();
	}

}
